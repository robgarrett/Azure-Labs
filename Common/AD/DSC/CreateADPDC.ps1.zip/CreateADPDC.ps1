﻿configuration CreateADPDC {
   param (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30)

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot;
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password);
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1;
    $InterfaceAlias=$($Interface.Name);

    Node localhost {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true;
        }

        # Install DNS Feature.
        WindowsFeature DNS {
            Ensure = "Present";
            Name = "DNS";
        }

        # Turn on diagnostics for DNS.
        Script EnableDNSDiags {
      	    SetScript = {
                Set-DnsServerDiagnostics -All $true;
                Write-Verbose -Verbose "Enabling DNS client diagnostics";
            }
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[WindowsFeature]DNS";
        }

        # Install DNS tools.
        WindowsFeature DnsTools {
            Ensure = "Present";
            Name = "RSAT-DNS-Server";
            DependsOn = "[WindowsFeature]DNS";
        }

        # Set local NIC to use this server as primary DNS.
        xDnsServerAddress DnsServerAddress {
            Address        = '127.0.0.1';
            InterfaceAlias = $InterfaceAlias;
            AddressFamily  = 'IPv4';
            DependsOn = "[WindowsFeature]DNS";
        }

        # Wait for Disk2 to come online.
        xWaitforDisk Disk2 {
            DiskNumber = 2;
            RetryIntervalSec =$RetryIntervalSec;
            RetryCount = $RetryCount;
        }

        # Assign F to Disk2.
        xDisk ADDataDisk {
            DiskNumber = 2;
            DriveLetter = "F";
            DependsOn = "[xWaitForDisk]Disk2";
        }

        # Install AD feature.
        WindowsFeature ADDSInstall {
            Ensure = "Present";
            Name = "AD-Domain-Services";
            DependsOn="[WindowsFeature]DNS";
        }

        # Install AD tools.
        WindowsFeature ADDSTools {
            Ensure = "Present";
            Name = "RSAT-ADDS-Tools";
            DependsOn = "[WindowsFeature]ADDSInstall";
        }

        # Install AD Admin Center.
        WindowsFeature ADAdminCenter {
            Ensure = "Present";
            Name = "RSAT-AD-AdminCenter";
            DependsOn = "[WindowsFeature]ADDSTools";
        }

        # Configure this server as Primary PDC.
        xADDomain FirstDS {
            DomainName = $DomainName;
            DomainAdministratorCredential = $DomainCreds;
            SafemodeAdministratorPassword = $DomainCreds;
            DatabasePath = "F:\NTDS";
            LogPath = "F:\NTDS";
            SysvolPath = "F:\SYSVOL";
            DependsOn = @("[WindowsFeature]ADDSInstall", "[xDisk]ADDataDisk");
        }

        # Reboot after promotion.
        xPendingReboot RebootAfterPromotion {
            Name = "RebootAfterPromotion";
            DependsOn = "[xADDomain]FirstDS";
        }
   }
}
