﻿configuration ConfigureADBDC {
   param (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30);

    Import-DscResource -ModuleName xActiveDirectory, xPendingReboot, xNetworking;
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        # Wait for forest to come online.
        xWaitForADDomain DscForestWait {
            DomainName = $DomainName;
            DomainUserCredential= $DomainCreds;
            RetryCount = $RetryCount;
            RetryIntervalSec = $RetryIntervalSec;
        }

        # Configure this server as a BDC.
        xADDomainController BDC {
            DomainName = $DomainName;
            DomainAdministratorCredential = $DomainCreds;
            SafemodeAdministratorPassword = $DomainCreds;
            DatabasePath = "F:\NTDS";
            LogPath = "F:\NTDS";
            SysvolPath = "F:\SYSVOL";
            DependsOn = "[xWaitForADDomain]DscForestWait";
        }

         # Set local NIC to use this server as primary DNS.
         xDnsServerAddress DnsServerAddress {
            Address        = '127.0.0.1';
            InterfaceAlias = $InterfaceAlias;
            AddressFamily  = 'IPv4';
            DependsOn = "[xADDomainController]BDC";
        }

        # Reboot after promotion.
        xPendingReboot RebootAfterPromotion {
            Name = "RebootAfterDCPromotion";
            DependsOn = "[xDnsServerAddress]DnsServerAddress";
        }
    }
}
