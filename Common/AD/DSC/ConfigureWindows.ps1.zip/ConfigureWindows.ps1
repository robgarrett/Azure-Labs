﻿configuration ConfigureWindows {
   param (
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30);

    Import-DscResource -ModuleName  ComputerManagementDsc;

    Node localhost {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        xTimeZone TimeZone
        {
            IsSingleInstance = 'Yes';
            TimeZone         = 'Eastern Standard Time';
        }
   }
}
