﻿configuration PrepareADBDC {
   param (
        [Parameter(Mandatory)]
        [String]$pdcDNSIPAddress,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30);

    Import-DscResource -ModuleName  xStorage, xNetworking
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        # Install DNS Feature.
        WindowsFeature DNS {
            Ensure = "Present";
            Name = "DNS";
        }

        # Turn on diagnostics for DNS.
        Script EnableDNSDiags {
      	    SetScript = {
                Set-DnsServerDiagnostics -All $true;
                Write-Verbose -Verbose "Enabling DNS client diagnostics";
            }
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[WindowsFeature]DNS";
        }

        # Install DNS tools.
        WindowsFeature DnsTools {
            Ensure = "Present";
            Name = "RSAT-DNS-Server";
            DependsOn = "[WindowsFeature]DNS";
        }

        # Set local NIC to use DNS of primary PDC.
        # This allows this server to find the existing domain.
        # After we've joined the domain we'll reset the DNS to this server.
        xDnsServerAddress DnsServerAddress {
            Address        = $pdcDNSIPAddress;
            InterfaceAlias = $InterfaceAlias;
            AddressFamily  = 'IPv4';
            DependsOn = "[WindowsFeature]DNS";
        }

        # Wait for Disk2 to come online.
        xWaitforDisk Disk2 {
            DiskNumber = 2;
            RetryIntervalSec =$RetryIntervalSec;
            RetryCount = $RetryCount;
        }

        # Assign F to Disk2.
        xDisk ADDataDisk {
            DiskNumber = 2;
            DriveLetter = "F";
            DependsOn = "[xWaitForDisk]Disk2";
        }

        # Install AD feature.
        WindowsFeature ADDSInstall {
            Ensure = "Present";
            Name = "AD-Domain-Services";
            DependsOn="[WindowsFeature]DNS";
        }

        # Install AD tools.
        WindowsFeature ADDSTools {
            Ensure = "Present";
            Name = "RSAT-ADDS-Tools";
            DependsOn = "[WindowsFeature]ADDSInstall";
        }

        # Install AD Admin Center.
        WindowsFeature ADAdminCenter {
            Ensure = "Present";
            Name = "RSAT-AD-AdminCenter";
            DependsOn = "[WindowsFeature]ADDSTools";
        }
   }
}
